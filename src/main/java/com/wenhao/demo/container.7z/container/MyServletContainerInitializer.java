package com.wenhao.demo.container;

import com.wenhao.demo.handles.MyHandlesType;
import com.wenhao.demo.servlet.PayServlet;

import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import javax.servlet.annotation.HandlesTypes;
import java.util.Set;

@HandlesTypes(MyHandlesType.class)
public class MyServletContainerInitializer implements ServletContainerInitializer {
    @Override
    public void onStartup(Set<Class<?>> c, ServletContext ctx) throws ServletException {
        for (Class<?> aClass : c) {
            System.out.println(aClass + "dy");
        }
        ServletRegistration.Dynamic payServlet = ctx.addServlet("payServlet", new PayServlet());
        payServlet.addMapping("/");
    }
}
